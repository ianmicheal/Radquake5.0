#include <kos.h>

void Host_WriteConfiguration (void);
void Host_ReadConfiguration (void);
